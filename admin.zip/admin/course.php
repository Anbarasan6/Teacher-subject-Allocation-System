<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['tsasaid']==0)) {
  header('location:logout.php');
  } else{
    if(isset($_POST['submit']))
  {

$tsasaid=$_SESSION['tsasaid'];
 $bname=$_POST['branchname'];
 $cname=$_POST['coursename'];
 $shift=$_POST['shift'];
 

$sql="insert into tblcourse(BranchName,CourseName,Shift)values(:branchname,:coursename,:shift)";
$query=$dbh->prepare($sql);
$query->bindParam(':branchname',$bname,PDO::PARAM_STR);
$query->bindParam(':coursename',$cname,PDO::PARAM_STR);
$query->bindParam(':shift',$shift,PDO::PARAM_STR);

 $query->execute();

   $LastInsertId=$dbh->lastInsertId();
   if ($LastInsertId>0) {
    echo '<script>alert("Course has been added.")</script>';
echo "<script>window.location.href ='course.php'</script>";
  }
  else
    {
         echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }

  
}
// Code for deleting product from cart
if(isset($_GET['delid']))
{
$rid=intval($_GET['delid']);
$sql="delete from tblcourse where ID=:rid";
$query=$dbh->prepare($sql);
$query->bindParam(':rid',$rid,PDO::PARAM_STR);
$query->execute();
 echo "<script>alert('Data deleted');</script>"; 
    


}

?>
<!DOCTYPE html>
<html lang="en-US">
<head>
    <title>TSAS : Course Create</title>

       <!-- Styles -->
    <link href="../assets/css/lib/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/lib/themify-icons.css" rel="stylesheet">
    <link href="../assets/css/lib/menubar/sidebar.css" rel="stylesheet">
    <link href="../assets/css/lib/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/lib/unix.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
        h3 span {
            font-size: 22px;
        }
        h3 input.search-input {
            width: 300px;
            margin-left: auto;
            float: right
        }
        .mt32 {
            margin-top: 32px;
        }
    </style>
	
</head>
<body class="mt32">
<?php include_once('includes/sidebar.php');?>
   
    <?php include_once('includes/header.php');?>
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8 p-r-0 title-margin-right">
                        <div class="page-header">
                            <div class="page-title">
                                <h1>Course</h1>
                            </div>
                        </div>
                    </div>
                    <!-- /# column -->
                    <div class="col-lg-4 p-l-0 title-margin-left">
                        <div class="page-header">
                            <div class="page-title">
                                <ol class="breadcrumb text-right">
                                    <li><a href="dashboard.php">Dashboard</a></li>
                                    <li class="active">Course</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- /# column -->
                </div>
                <!-- /# row -->
				
                <div id="main-content">
                    <h4><div class="row ">
                        <div class="col-md-12">
                            <div class="card alert">
                                <div class="card-header pr">
                                    <h4>Create A New Course</h4>
                                    <form method="post" name="hjhgh">
                                        <div class="basic-form m-t-20">
                                            <div class="form-group">
                                                <label>Course</label>
        <input type="text" class="form-control border-none input-flat bg-ash" placeholder="Course Name" name="coursename" required="true">
                                            </div>
                                        </div>
                                        <div class="basic-form m-t-20">
                                            <div class="form-group">
                                                <label>Department Name</label>
                                                <input type="text" class="form-control border-none input-flat bg-ash" placeholder="Branch Name" name="branchname" required="true">
                                            </div>
                                        </div>
										<div class="basic-form m-t-20">
                                            <div class="form-group">
                                                <label>Shift</label>
												<select class="form-control border-none input-flat bg-ash" name="shift" required="true">
												<option value="">Select Shift</option>
												<option value="Shift-I">Shift-I</option>
												<option value="Shift-II">Shift-II</option>
												<option value="Shift-I & Shift-II">Shift-I & Shift-II</option>
												
										</select>
                                            </div>
                                        </div>
                                   
                                </div>
                                <button class="btn btn-default btn-lg m-b-10 bg-warning border-none m-r-5 sbmt-btn" type="submit" name="submit">Save</button>
                                <button class="btn btn-default btn-lg m-b-10   sbmt-btn" type="reset">Reset</button> 
                           </h4> </form>
                            </div>
                        </div>
    <div class="container ">
        <h3>
            <span>ALL Course</span>
            <input type="search" placeholder="Search..." class="form-control search-input" data-table="customers-list"/>
        </h3>
        <table class="table table-striped mt32 customers-list table-bordered">
            <thead>
                <tr>
                    <th><h3><center>S.No</center></h3></th>
					<th><h3>Course </h3></th>
                    <th><h3>Department Name</h3></th>
					<th><h3><center>Shift</center></h3></th>
                   <th><h3><center>Action</center></h3></th>
                </tr>
            </thead>
			<tbody>
			<?php
$sql="SELECT * from tblcourse";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);

$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $row)
{               ?>
                <tr>
                                                    <td><h5><center><?php echo htmlentities($cnt);?></center></h5></td>
                                                    <td>
                                                        <h5><?php  echo htmlentities($row->CourseName);?></h5>
                                                    </td>
                                                    <td>
                                                        <h5><?php  echo htmlentities($row->BranchName);?></h5>
                                                    </td>
													<td>
                                                        <h5><center><?php  echo htmlentities($row->Shift);?></center></h5>
                                                    </td>
                                                   
                                                    <td>
                                                       
                                                       <h4><center> <span><a href="edit-course.php?editid=<?php echo htmlentities ($row->ID);?>"><i class="ti-pencil-alt color-success"></i></a></span>
                                                        <span><a href="course.php?delid=<?php echo ($row->ID);?>"  onclick="return confirm('Do you really want to Delete ?');"><i class="ti-trash color-danger"></i> </a></span>
                                                    </center></h4>
													</td>
                                                </tr>
												<?php $cnt=$cnt+1;}} ?> 
            </tbody>
        </table>
    </div>
    <script>
        (function(document) {
            'use strict';

            var TableFilter = (function(myArray) {
                var search_input;

                function _onInputSearch(e) {
                    search_input = e.target;
                    var tables = document.getElementsByClassName(search_input.getAttribute('data-table'));
                    myArray.forEach.call(tables, function(table) {
                        myArray.forEach.call(table.tBodies, function(tbody) {
                            myArray.forEach.call(tbody.rows, function(row) {
                                var text_content = row.textContent.toLowerCase();
                                var search_val = search_input.value.toLowerCase();
                                row.style.display = text_content.indexOf(search_val) > -1 ? '' : 'none';
                            });
                        });
                    });
                }

                return {
                    init: function() {
                        var inputs = document.getElementsByClassName('search-input');
                        myArray.forEach.call(inputs, function(input) {
                            input.oninput = _onInputSearch;
                        });
                    }
                };
            })(Array.prototype);

            document.addEventListener('readystatechange', function() {
                if (document.readyState === 'complete') {
                    TableFilter.init();
                }
            });

        })(document);
    </script>
	<?php include_once('includes/footer.php');?>
	
	<!-- jquery vendor -->
    <script src="../assets/js/lib/jquery.min.js"></script>
    <script src="../assets/js/lib/jquery.nanoscroller.min.js"></script>
    <!-- nano scroller -->
    <script src="../assets/js/lib/menubar/sidebar.js"></script>
    <script src="../assets/js/lib/preloader/pace.min.js"></script>
    <!-- sidebar -->
    <script src="../assets/js/lib/bootstrap.min.js"></script>
    <!-- bootstrap -->
    <script src="../assets/js/scripts.js"></script>
    <!-- scripit init-->
	
</body>
</html><?php }  ?>
