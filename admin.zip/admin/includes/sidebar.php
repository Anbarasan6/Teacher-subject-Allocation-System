
<div class="sidebar sidebar-hide-to-small bg-dark sidebar-shrink sidebar-gestures">
        <div class="nano">
            <div class="nano-content">
                <ul>

                    <li class="label">Main</li>
                    <li><a href="dashboard.php" ><i class="ti-home"></i>Dashboard</a></li>
                   <li><a href="course.php"><i class="ti-files"></i>Course</a>
                    </li>
                     <li><a href="subject.php"><i class="ti-files"></i>Subject</a>
                    </li>
                    

                 
                    <li class="label">Apps</li>
                    <li><a class="sidebar-sub-toggle"><i class="ti-user"></i>  Teacher  <span class="sidebar-collapse-icon ti-angle-down"></span></a>
                        <ul>
                             <li><a href="add-teacher.php">Add Teacher</a>
                    </li>
                            <li><a href="manage-teacher.php">Manage Teacher</a></li>
                           
                        </ul>
                    </li>
                      <li><a href="subject-allocation.php"><i class="ti-files"></i>Subject Allocation</a>
                    </li>
                   
                  <li><a href="search.php" ><i class="ti-search"></i>Search</a></li>
                </ul>
            </div>
        </div>
    </div>  

    