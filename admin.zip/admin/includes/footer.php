





<footer class="footer bg-pink text-light">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <center><h4 style="color: white">© Copyright 2024 - All Rights Reserved</h4>
				<h4 style="color: red">Developed by Anbarasan</center>
				
				
            </div>
            
        </div>
    </div>
</footer>


